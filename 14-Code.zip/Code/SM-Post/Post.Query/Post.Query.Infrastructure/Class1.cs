﻿namespace Post.Query.Infrastructure;
public class Class1
{

}
