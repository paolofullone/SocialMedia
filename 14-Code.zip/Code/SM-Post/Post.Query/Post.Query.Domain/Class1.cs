﻿namespace Post.Query.Domain;
public class Class1
{

}
