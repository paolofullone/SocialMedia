﻿namespace Post.Cmd.Infrastructure;
public class Class1
{

}
