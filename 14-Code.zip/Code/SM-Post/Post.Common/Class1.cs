﻿namespace Post.Common;
public class Class1
{

}
