using CQRS.Core.Commands;

namespace Post.Cmd.Api.Commands
{
    public class RestoreReadDbCommand : BaseCommand
    {
    }
}